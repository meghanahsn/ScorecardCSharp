﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Reports;
using System.IO;
using System.Data.OleDb;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

using System.Drawing.Printing;


namespace marks_card
{
    public partial class Form1 : Form
    {
        // private const int MaxFormWidth = 820, MaxFormHeight = 753;
        public Form1()
        {
            InitializeComponent();
            //this.Location = new System.Drawing.Point(ScreenLen - WinLen, ScreenHeigh - WinHeigh);
            //System.Drawing.Rectangle screen = Screen.PrimaryScreen.Bounds;
            // System.Drawing.Point maximizedLocation = new System.Drawing.Point((screen.Width - MaxFormWidth) / 2,(screen.Height - MaxFormHeight) / 2);

            //this.MaximumSize = new Size(MaxFormWidth, MaxFormHeight);
            //this.MaximizedBounds = new System.Drawing.Rectangle(maximizedLocation, this.MaximumSize);
            //this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterParent;



        }


        public String str_semis_in_words = "";

        private void btn_proceed_Click(object sender, EventArgs e)
        {
            int count = dataGridView1.Rows.Count - 1;
            if (cls_sub_data.count_next_record > count)
            {
                MessageBox.Show("there is no Records");
                return;
            }

            System.Data.DataTable dt_marks = new System.Data.DataTable();
            DataColumn slno = new DataColumn("Slno");
            dt_marks.Columns.Add(slno);
            dt_marks.Columns.Add("Subject_name");
            dt_marks.Columns.Add("sessional_max");
            dt_marks.Columns.Add("examination_max");
            dt_marks.Columns.Add("seesion_ob");
            dt_marks.Columns.Add("exam_ob");
            dt_marks.Columns.Add("Remarks");

            String[] sem_arry = new String[10];


            if (comboBox_sem.SelectedItem.ToString() != "<--Select-->")
            {
                switch (comboBox_sem.SelectedItem.ToString())
                {
                    case "1": sem_arry = new String[cls_sub_data.sem_2_data.Length];
                        cls_sub_data.sem_2_data.CopyTo(sem_arry, 0);
                        str_semis_in_words = "FIRST ";
                        break;
                    case "2":
                        sem_arry = new String[cls_sub_data.sem_2_data.Length];
                        cls_sub_data.sem_2_data.CopyTo(sem_arry, 0);
                        str_semis_in_words = "SECOND";
                        break;
                    case "3": sem_arry = new String[cls_sub_data.sem_2_data.Length];
                        cls_sub_data.sem_2_data.CopyTo(sem_arry, 0);
                        str_semis_in_words = "THIRD ";
                        break;
                    case "4":
                        sem_arry = new String[cls_sub_data.sem_2_data.Length];
                        cls_sub_data.sem_2_data.CopyTo(sem_arry, 0);
                        str_semis_in_words = "FOURTH ";
                        break;
                    case "5": sem_arry = new String[cls_sub_data.sem_2_data.Length];
                        cls_sub_data.sem_2_data.CopyTo(sem_arry, 0);
                        str_semis_in_words = "FIFTH ";
                        break;
                    case "6": sem_arry = new String[cls_sub_data.sem_2_data.Length];
                        cls_sub_data.sem_2_data.CopyTo(sem_arry, 0);
                        str_semis_in_words = "SIXTH ";
                        break;
                    default: MessageBox.Show("invalid sem Selection"); break;
                }

            }
            else
            {
                MessageBox.Show("Please Select Valid Semester");
                comboBox_sem.Focus();
            }



            if (dataGridView1.Rows.Count > 0)
            {

                String cols = dataGridView1.Columns[1].Name;
                for (int i = 0; i < cls_sub_data.coloumn.Count; i++)
                {
                    DataRow dtr_ = dt_marks.NewRow();

                    dtr_["Slno"] = "";
                    dtr_["Subject_name"] = cls_sub_data.coloumn[i];
                    dtr_["sessional_max"] = cls_sub_data.Max_ses_val[i].ToString();
                    dtr_["examination_max"] = cls_sub_data.max_exam_val[i].ToString();



                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        String str_grid_col = dataGridView1.Columns[j].Name;

                        String str_cc = cls_sub_data.coloumn[i].ToString().Trim();


                        if (str_grid_col.Contains(str_cc) && str_grid_col.Contains("sessional"))
                        {
                            dtr_["seesion_ob"] = dataGridView1.Rows[cls_sub_data.count_next_record].Cells[j].Value.ToString();
                        }

                        if (str_grid_col.Contains(str_cc) && str_grid_col.Contains("exam"))
                        {
                            dtr_["exam_ob"] = dataGridView1.Rows[cls_sub_data.count_next_record].Cells[j].Value.ToString();
                        }
                    }

                    dtr_["Remarks"] = " ";
                    dt_marks.Rows.Add(dtr_);
                }

                txt_father_name.Text = dataGridView1.Rows[cls_sub_data.count_next_record].Cells[2].Value.ToString();
                txt_student_name.Text = dataGridView1.Rows[cls_sub_data.count_next_record].Cells[1].Value.ToString();
                txt_examination_center.Text = dataGridView1.Rows[cls_sub_data.count_next_record].Cells[3].Value.ToString();
                txt_reg_no.Text = dataGridView1.Rows[cls_sub_data.count_next_record].Cells[0].Value.ToString();
            }
            cls_sub_data.count_next_record++;
            dataGridView_marks.DataSource = dt_marks;
            dataGridView_marks.ReadOnly = true;

        }

        private void btn_generate_Click(object sender, EventArgs e)
        {
            if (check_all_text_box() < 0)
            {
                return;
            }

            String str_folder = "";
            if (txt_file_to_save_marks_card.Text != "")
            {
                str_folder = txt_file_to_save_marks_card.Text;
            }
            else
            {
                str_folder = "C:\\reports";
            }


            String str_certificate_name = "C:\\reports\\Certificates_val.xlsx";

            String strFileName = @str_folder + "\\" + txt_reg_no.Text + "_" + txt_student_name.Text + "Marks_card.pdf";


            try
            {


            }
            catch (Exception ex)
            {

            }
            try
            {
                cls_marks_data m_card_data = new cls_marks_data();

                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                if (xlApp == null)
                {
                    return;
                }

                Excel.Workbook xlWorkBook = xlApp.Workbooks.Open(str_certificate_name, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Type.Missing);

                Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                object misValue = System.Reflection.Missing.Value;

                Range excelRange = xlWorkSheet.UsedRange;




                int rows = xlWorkSheet.UsedRange.Rows.Count + 1;

                for (int i = 0; i < dataGridView_marks.Rows.Count - 1; i++)
                {
                    if (dataGridView_marks.Rows[i].Cells[5].Value.ToString() != "0")
                    {
                        m_card_data.m_external_max_lst.Add(dataGridView_marks.Rows[i].Cells[3].Value.ToString());
                        m_card_data.m_sessional_max_lst.Add(dataGridView_marks.Rows[i].Cells[2].Value.ToString());
                        m_card_data.m_sessional_obt_lst.Add(dataGridView_marks.Rows[i].Cells[4].Value.ToString());
                        m_card_data.m_external_obt_lst.Add(dataGridView_marks.Rows[i].Cells[5].Value.ToString());
                        m_card_data.m_subject__namelst.Add(dataGridView_marks.Rows[i].Cells[1].Value.ToString());
                        m_card_data.m_Remark_obt_lst.Add(dataGridView_marks.Rows[i].Cells[6].Value.ToString());
                    }
                    else
                    {
                        m_card_data.m_external_max_lst.Add("");
                        m_card_data.m_sessional_max_lst.Add("");
                        m_card_data.m_sessional_obt_lst.Add("");
                        m_card_data.m_external_obt_lst.Add("");
                        m_card_data.m_subject__namelst.Add("");
                        m_card_data.m_Remark_obt_lst.Add("");
                    }
                    
                }

                m_card_data.m_date_of_issue.str_value = dateTimePicker_date_of_issue.Value.ToShortDateString();
                m_card_data.m_student_name.str_value = txt_student_name.Text;
                m_card_data.m_father_name.str_value = txt_father_name.Text;
                m_card_data.m_reg_no.str_value = txt_reg_no.Text;
                m_card_data.m_result.str_value = txt_result.Text;
                m_card_data.m_Semester.str_value = str_semis_in_words;
                m_card_data.m_total_marks_in_word.str_value = txt_total_marks_words.Text;
                m_card_data.m_center_code.str_value = txt_examination_center.Text;
                m_card_data.m_exam_held.str_value = comboBox_exam_held.SelectedItem.ToString();
                m_card_data.m_exam_center.str_value = comboBox_center_code.SelectedItem.ToString();

                m_card_data.m_external_max.str_value = txt_external_tt_max.Text;
                m_card_data.m_external_obt.str_value = txt_exam_obt.Text;
                m_card_data.m_sessional_max.str_value = txt_internal_max.Text;
                m_card_data.m_sessional_obt.str_value = txt_internal_obt.Text;
                m_card_data.m_both_tt.str_value = txt_tt_obt.Text;


                xlWorkSheet.Cells[rows, 1] = txt_reg_no.Text;
                xlWorkSheet.Cells[rows, 2] = txt_student_name.Text;
                xlWorkSheet.Cells[rows, 3] = txt_examination_center.Text;

                String str_result = txt_result.Text;
                String[] str_value = str_result.Split(':');

                xlWorkSheet.Cells[rows, 4] = str_value[1].Trim();

                m_card_data.m_result.str_value = txt_result.Text;
                m_card_data.m_total_marks_in_word.str_value = txt_total_marks_words.Text;
                m_card_data.m_Verified_by.str_value = "temp";


                cls_marks_card_pdf marks_card = new cls_marks_card_pdf();
                marks_card.new_marks_card_generation(m_card_data, strFileName);

                xlWorkBook.Save();
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
                releaseObject(xlWorkSheet);
                releaseObject(xlWorkBook);
                releaseObject(xlApp);
                System.Diagnostics.Process.Start(strFileName);

                MessageBox.Show("Generated , please minimize screen and look for pdf in c:\\Report");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Please contact admin" + ex.Message);
            }

        }

        protected int check_all_text_box()
        {
            if (txt_examination_center.Text == "" || txt_examination_center.Text == null)
            {
                MessageBox.Show("PLease Enter the Examination center");
                return -1;
            }

            if (txt_father_name.Text == "" || txt_father_name.Text == null)
            {
                MessageBox.Show("PLease Enter the Fathere Name ");
                return -1;
            }

            if (txt_father_name.Text == "" || txt_father_name.Text == null)
            {
                MessageBox.Show("PLease Enter the Fathere Name ");
                return -1;
            }

            if (txt_student_name.Text == "" || txt_student_name.Text == null)
            {
                MessageBox.Show("PLease Enter the student Name ");
                return -1;
            }

            if (txt_reg_no.Text == "" || txt_reg_no.Text == null)
            {
                MessageBox.Show("PLease Enter the Register Numer");
                return -1;
            }

            if (txt_father_name.Text == "" || txt_father_name.Text == null)
            {
                MessageBox.Show("PLease Enter the Father Name ");
                return -1;
            }

            if (txt_father_name.Text == "" || txt_father_name.Text == null)
            {
                MessageBox.Show("PLease Enter the Father Name ");
                return -1;
            }

            if (txt_tt_obt.Text == "" || txt_tt_obt.Text == null)
            {
                MessageBox.Show("Please press Calculate button before proceeding to Marks card Generation ");
                return -1;
            }
            return 1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //FormBorderStyle = FormBorderStyle.Sizable;
            // WindowState = FormWindowState.Maximized;
            //TopMost = true;



            comboBox_sem.SelectedIndex = 1;
            comboBox_exam_held.SelectedIndex = 1;
            comboBox_center_code.SelectedIndex = 1;
        }





        private void btn_calculate_Click(object sender, EventArgs e)
        {
            float internal_marks = 0;
            float external_marks = 0;
            float max_internal_marks = 0;
            float max_external_markd = 0;
            Boolean fail = false;
            Boolean invalid = false;

            if (dataGridView_marks.Rows.Count <= 0)
            {
                MessageBox.Show("There no Marks Details to Proceed please select Sem and proceed");
                return;
            }

            for (int i = 0; i < dataGridView_marks.Rows.Count - 1; i++)
            {
                try
                {
                    dataGridView_marks.Rows[i].Cells[6].Value = "";


                    int min_session_m = int.Parse(cls_sub_data.min_ses_val[i]);
                    int min_obtain_m = int.Parse(cls_sub_data.min_exam_val[i]);

                    if (dataGridView_marks.Rows[i].Cells[5].Value.ToString() != "0")
                    {
                        max_external_markd = max_external_markd + float.Parse(dataGridView_marks.Rows[i].Cells[3].Value.ToString());
                        max_internal_marks = max_internal_marks + float.Parse(dataGridView_marks.Rows[i].Cells[2].Value.ToString());
                        internal_marks = internal_marks + float.Parse(dataGridView_marks.Rows[i].Cells[4].Value.ToString());
                        external_marks = external_marks + float.Parse(dataGridView_marks.Rows[i].Cells[5].Value.ToString());

                        if (float.Parse(dataGridView_marks.Rows[i].Cells[5].Value.ToString()) < min_obtain_m || (float.Parse(dataGridView_marks.Rows[i].Cells[5].Value.ToString()) + float.Parse(dataGridView_marks.Rows[i].Cells[5].Value.ToString())) < (min_obtain_m + min_session_m))
                        {
                            fail = true;
                            dataGridView_marks.Rows[i].Cells[6].Value = "***";
                        }

                        if (float.Parse(dataGridView_marks.Rows[i].Cells[5].Value.ToString()) < 0 || float.Parse(dataGridView_marks.Rows[i].Cells[5].Value.ToString()) < 0)
                        {
                            invalid = true;
                            dataGridView_marks.Rows[i].Cells[6].Value = "***";
                        }

                    }




                }
                catch (Exception ex)
                {

                    MessageBox.Show("You might have Entered Wrong Data Please cross verify or contact Admin");
                    return;
                }


            }

            txt_external_tt_max.Text = max_external_markd.ToString();
            txt_internal_max.Text = max_internal_marks.ToString();
            txt_internal_obt.Text = internal_marks.ToString();
            txt_exam_obt.Text = external_marks.ToString();

            txt_tt_obt.Text = (internal_marks + external_marks).ToString();

            float percent = (internal_marks + external_marks) / (max_internal_marks + max_external_markd) * 100;

            char[] char_1 = txt_tt_obt.Text.ToCharArray();
            String str_words = "";

            for (int i = 0; i < char_1.Length; i++)
            {
                str_words = str_words + num_to_string(int.Parse(char_1[i].ToString())) + " ";
            }
            //num_to_string();

            txt_total_marks_words.Text = str_words.ToUpper();


            if (fail == true)
            {
                txt_result.Text = " FAIL : FAIL";
            }
            else
            {

                if (percent > 50 && percent < 70)
                {
                    txt_result.Text = " PASS :  SECOND CLASS";
                }
                if (percent >= 70 && percent <= 80)
                {
                    txt_result.Text = " PASS :  FIRST CLASS";
                }


                if (percent >= 80 && percent <= 100)
                {
                    txt_result.Text = " PASS :  DISTINCTION";
                }

                if (percent >= 0 && percent <= 35)
                {
                    txt_result.Text = " FAIL : FAIL";
                }
                if (percent > 100)
                {
                    txt_result.Text = " Invalid :   ";
                }

                if (invalid)
                {
                    txt_result.Text = "Invalid";
                }
            }

        }


        protected String num_to_string(int num)
        {
            switch (num)
            {

                case 1:
                    return "One";
                    break;
                case 2:
                    return "Two";
                    break;
                case 3:
                    return "Three";
                    break;

                case 4:
                    return "Four";
                    break;
                case 5:
                    return "Five";
                    break;
                case 6:
                    return "Six";
                    break;
                case 7:
                    return "Seven";
                    break;

                case 8:
                    return "Eight";
                    break;
                case 9:
                    return "Nine";
                    break;
                case 0:
                    return "ZERO";
                    break;
                default: return ""; break;
            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                FormBorderStyle = FormBorderStyle.Sizable;
                WindowState = FormWindowState.Minimized;
                TopMost = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            System.Data.DataTable dt_exam_marks = new System.Data.DataTable();
            System.Data.DataTable dt_sessional_marks = new System.Data.DataTable();
            System.Data.DataTable dt_min_max_marks = new System.Data.DataTable();
            System.Data.DataTable all_tb = new System.Data.DataTable();

            DataSet ds = new DataSet();

            // dt_marks.Columns.Add("Remarks");


            string filePath = string.Empty;
            string fileExt = string.Empty;
            OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file  
            if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK) //if there is a file choosen by the user  
            {
                filePath = file.FileName; //get the path of the file  
                fileExt = Path.GetExtension(filePath); //get the file extension  
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        txt_file_path.Text = filePath;
                        //System.Data.DataTable dtExcel = new System.Data.DataTable();
                        //dtExcel = ReadExcel(filePath, fileExt); //read excel file  
                        //dataGridView1.Visible = true;
                        //                        dataGridView1.DataSource = dtExcel;

                        Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                        if (xlApp == null)
                        {

                            return;
                        }

                        // String savePath = @"c:\raj\";
                        //String fileName = FileUpload1.FileName;

                        // Append the name of the file to upload to the path.
                        //  savePath += fileName;


                        // FileUpload1.SaveAs(savePath);

                        // String File_path = Path.GetFullPath(FileUpload1.FileName);
                        Excel.Workbook xlWorkBook = xlApp.Workbooks.Open(filePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                    Type.Missing, Type.Missing);

                        Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                        object misValue = System.Reflection.Missing.Value;

                        Range excelRange = xlWorkSheet.UsedRange;

                        object[,] valueArray = (object[,])excelRange.get_Value(
                            XlRangeValueDataType.xlRangeValueDefault);




                        for (int row = 1; row <= xlWorkSheet.UsedRange.Rows.Count; ++row)
                        {
                            if (row == 1)
                            {
                                if (valueArray[row, 1] != null)
                                {
                                    String colo_na = valueArray[row, 1].ToString();
                                    dt_exam_marks.Columns.Add(valueArray[row, 2].ToString()); //Reg.No
                                    dt_exam_marks.Columns.Add(valueArray[row, 3].ToString()); //Name
                                    dt_exam_marks.Columns.Add(valueArray[row, 4].ToString()); //Father name
                                    dt_exam_marks.Columns.Add(valueArray[row, 5].ToString()); //Centre

                                    colo_na = valueArray[row, 6].ToString();

                                    String[] strp_col = colo_na.Split('.');
                                    colo_na = strp_col[0];

                                    cls_sub_data.coloumn.Add(colo_na);
                                    dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                    dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                    dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501

                                    if (valueArray[row, 9] != null)
                                    {
                                        colo_na = valueArray[row, 9].ToString();
                                        String[] strp_col5 = colo_na.Split('.');
                                        colo_na = strp_col5[0];
                                        cls_sub_data.coloumn.Add(colo_na); //2 
                                        dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                        dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                        dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501
                                    }


                                    if (valueArray[row, 12] != null)
                                    {
                                        colo_na = valueArray[row, 12].ToString();
                                        String[] strp_col1 = colo_na.Split('\n');
                                        colo_na = strp_col1[0];
                                        cls_sub_data.coloumn.Add(colo_na); //3
                                        dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                        dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                        dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501
                                    }


                                    if (valueArray[row, 15] != null)
                                    {
                                        colo_na = valueArray[row, 15].ToString();
                                        String[] strp_col6 = colo_na.Split('.');
                                        colo_na = strp_col6[0];
                                        cls_sub_data.coloumn.Add(colo_na); //4 
                                        dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                        dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                        dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501
                                    }

                                    if (valueArray[row, 18] != null)
                                    {

                                        colo_na = valueArray[row, 18].ToString();
                                         if (!(colo_na.Contains("Total") || colo_na.Contains("TOTAL") || colo_na.Contains("RESULT")))
                                        {
                                            String[] strp_col2 = colo_na.Split('.');
                                            colo_na = strp_col2[0];
                                            cls_sub_data.coloumn.Add(colo_na); //5 
                                            dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                            dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                            dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501
                                        }

                                    }

                                    if (valueArray[row, 21] != null)
                                    {
                                        colo_na = valueArray[row, 21].ToString();
                                        if (!(colo_na.Contains("Total") || colo_na.Contains("TOTAL") || colo_na.Contains("RESULT")))
                                        {

                                            String[] strp_col7 = colo_na.Split('.');
                                            colo_na = strp_col7[0];
                                            cls_sub_data.coloumn.Add(colo_na); //6 
                                            dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                            dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                            dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501
                                        }
                                    }


                                    if (valueArray[row, 24] != null)
                                    {
                                        colo_na = valueArray[row, 24].ToString();
                                        if (!(colo_na.Contains("Total") || colo_na.Contains("TOTAL") || colo_na.Contains("RESULT")))
                                        {
                                            String[] strp_col3 = colo_na.Split('.');
                                            colo_na = strp_col3[0];
                                            cls_sub_data.coloumn.Add(colo_na); //7 
                                            dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                            dt_exam_marks.Columns.Add(colo_na + "_exam");  //[DTDMVS501
                                            dt_exam_marks.Columns.Add(colo_na + "_total"); //[DTDMVS501
                                        }
                                    }


                                    if (valueArray[row, 27] != null)
                                    {
                                        colo_na = valueArray[row, 27].ToString();
                                         if (!(colo_na.Contains("Total") || colo_na.Contains("TOTAL") || colo_na.Contains("RESULT")))
                                        {
                                            String[] strp_col4 = colo_na.Split('.');
                                            colo_na = strp_col4[0];
                                            cls_sub_data.coloumn.Add(colo_na); //8 
                                            dt_exam_marks.Columns.Add(colo_na + "_sessional");
                                            dt_exam_marks.Columns.Add(colo_na + "_exam"); //[DTDMVS501
                                            dt_exam_marks.Columns.Add(colo_na + "_total"); //[   
                                        }
                                    }

                                }
                            }


                            if (row == 3)
                            {
                                if (valueArray[row, 6] != null)
                                {
                                    cls_sub_data.Max_ses_val.Add(valueArray[row, 6].ToString());
                                    cls_sub_data.max_exam_val.Add(valueArray[row, 7].ToString());

                                    if (valueArray[row, 9] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 9].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 10].ToString());
                                    }

                                    if (valueArray[row, 12] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 12].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 13].ToString());
                                    }

                                    if (valueArray[row, 15] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 15].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 16].ToString());
                                    }


                                    if (valueArray[row, 18] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 18].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 19].ToString());
                                    }

                                    if (valueArray[row, 21] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 21].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 22].ToString());
                                    }

                                    if (valueArray[row, 24] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 24].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 25].ToString());
                                    }

                                    if (valueArray[row, 27] != null)
                                    {
                                        cls_sub_data.Max_ses_val.Add(valueArray[row, 27].ToString());
                                        cls_sub_data.max_exam_val.Add(valueArray[row, 28].ToString());
                                    }

                                }
                            }

                            if (row == 4)
                            {
                                if (valueArray[row, 6] != null)
                                {
                                    cls_sub_data.min_ses_val.Add(valueArray[row, 6].ToString());
                                    cls_sub_data.min_exam_val.Add(valueArray[row, 7].ToString());

                                    cls_sub_data.min_ses_val.Add(valueArray[row, 9].ToString());
                                    cls_sub_data.min_exam_val.Add(valueArray[row, 10].ToString());

                                    if (valueArray[row, 12] != null)
                                    {
                                        cls_sub_data.min_ses_val.Add(valueArray[row, 12].ToString());
                                        cls_sub_data.min_exam_val.Add(valueArray[row, 13].ToString());
                                    }

                                    if (valueArray[row, 15] != null)
                                    {
                                        cls_sub_data.min_ses_val.Add(valueArray[row, 15].ToString());
                                        cls_sub_data.min_exam_val.Add(valueArray[row, 16].ToString());
                                    }


                                    if (valueArray[row, 18] != null)
                                    {
                                        cls_sub_data.min_ses_val.Add(valueArray[row, 18].ToString());
                                        cls_sub_data.min_exam_val.Add(valueArray[row, 19].ToString());

                                    }
                                    if (valueArray[row, 21] != null)
                                    {
                                        cls_sub_data.min_ses_val.Add(valueArray[row, 21].ToString());
                                        cls_sub_data.min_exam_val.Add(valueArray[row, 22].ToString());
                                    }


                                    if (valueArray[row, 24] != null)
                                    {
                                        cls_sub_data.min_ses_val.Add(valueArray[row, 24].ToString());
                                        cls_sub_data.min_exam_val.Add(valueArray[row, 25].ToString());

                                    }

                                    if (valueArray[row, 27] != null)
                                    {
                                        cls_sub_data.min_ses_val.Add(valueArray[row, 27].ToString());
                                        cls_sub_data.min_exam_val.Add(valueArray[row, 28].ToString());

                                    }


                                }
                            }

                            if (row > 4)
                            {
                                DataRow dtr_ = dt_exam_marks.NewRow();
                                for (int i = 1; i <= dt_exam_marks.Columns.Count; i++)
                                {
                                    int j = i + 1;
                                    if (valueArray[row, 1 + i] != null)
                                    {
                                        if (valueArray[row, 1 + i].ToString() != "-")
                                        {
                                            String str_test = valueArray[row, 1 + i].ToString();
                                            dtr_[i - 1] = valueArray[row, 1 + i].ToString();
                                        }
                                    }
                                    else
                                    {
                                        dtr_[i - 1] = "0"; // put NA if you put NA u need to modify in calculation
                                    }


                                }
                                dt_exam_marks.Rows.Add(dtr_);
                            }
                        }



                        dataGridView1.DataSource = dt_exam_marks;

                        xlWorkBook.Save();
                        xlWorkBook.Close(true, misValue, misValue);
                        xlApp.Quit();

                        releaseObject(xlWorkSheet);
                        releaseObject(xlWorkBook);
                        releaseObject(xlApp);

                    }


                    catch (Exception ex)
                    {
                        MessageBox.Show("Data Imported ");
                    }
                }
                else
                {
                    MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error  
                }

                dataGridView1.DataSource = dt_exam_marks;
            }




        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());

            }
            finally
            {
                GC.Collect();
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            clear();
        }

        protected void clear()
        {
            txt_exam_obt.Text = "";
            txt_examination_center.Text = "";
            txt_external_tt_max.Text = "";
            txt_father_name.Text = "";
            txt_file_path.Text = "";
            txt_internal_max.Text = "";
            txt_internal_obt.Text = "";
            txt_reg_no.Text = "";
            txt_result.Text = "";
            txt_student_name.Text = "";
            txt_total_marks_words.Text = "";
            txt_certi_sele_path.Text = "";
            txt_file_to_save_marks_card.Text = "";
            txt_tt_obt.Text = "";
            cls_sub_data.count_next_record = 0;
            cls_sub_data.min_exam_val.Clear();
            cls_sub_data.min_ses_val.Clear();
            cls_sub_data.min_val.Clear();
            cls_sub_data.max_exam_val.Clear();
            cls_sub_data.max_val.Clear();

            dataGridView_marks.DataSource = null;
            //dataGridView_marks.ReadOnly = true;
            dataGridView1.DataSource = null;
            // dataGridView1.ReadOnly = true;
        }


        private void btn_close_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btn_read_cetificate_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dt_certificate = new System.Data.DataTable();


            string filePath = string.Empty;
            string fileExt = string.Empty;
            OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file  
            if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK) //if there is a file choosen by the user  
            {
                filePath = file.FileName; //get the path of the file  
                fileExt = Path.GetExtension(filePath); //get the file extension  
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        txt_certi_file.Text = filePath;

                        Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                        if (xlApp == null)
                        {
                            return;
                        }

                        Excel.Workbook xlWorkBook = xlApp.Workbooks.Open(filePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                    Type.Missing, Type.Missing);

                        Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                        object misValue = System.Reflection.Missing.Value;

                        Range excelRange = xlWorkSheet.UsedRange;

                        object[,] valueArray = (object[,])excelRange.get_Value(
                            XlRangeValueDataType.xlRangeValueDefault);
                        for (int row = 1; row <= xlWorkSheet.UsedRange.Rows.Count; ++row)
                        {
                            if (row == 1)
                            {
                                if (valueArray[row, 1] != null)
                                {
                                    dt_certificate.Columns.Add(valueArray[row, 1].ToString());
                                    dt_certificate.Columns.Add(valueArray[row, 2].ToString());
                                    dt_certificate.Columns.Add(valueArray[row, 3].ToString());
                                    dt_certificate.Columns.Add(valueArray[row, 4].ToString());
                                }

                            }

                            if (row > 1)
                            {
                                DataRow dt_row_cert = dt_certificate.NewRow();
                                dt_row_cert[0] = valueArray[row, 1].ToString();
                                dt_row_cert[1] = valueArray[row, 2].ToString();
                                dt_row_cert[2] = valueArray[row, 3].ToString();
                                dt_row_cert[3] = valueArray[row, 4].ToString();

                                dt_certificate.Rows.Add(dt_row_cert);
                            }
                        }
                        dataGridView_Certificate.DataSource = dt_certificate;
                        dataGridView_Certificate.ReadOnly = true;
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
        }

        private void btn_generate_certificate_Click(object sender, EventArgs e)
        {

            String str_folder = "";
            if (txt_certi_sele_path.Text != "")
            {
                str_folder = txt_certi_sele_path.Text;
            }
            else
            {
                str_folder = "C:\\reports";
            }

            for (int i = 0; i < dataGridView_Certificate.Rows.Count - 1; i++)
            {

                cls_marks_data data_cert = new cls_marks_data();
                data_cert.str_cert_name = dataGridView_Certificate.Rows[i].Cells[1].Value.ToString();
                data_cert.str_reg_no = dataGridView_Certificate.Rows[i].Cells[0].Value.ToString();
                data_cert.str_center = dataGridView_Certificate.Rows[i].Cells[2].Value.ToString();
                data_cert.str_result = dataGridView_Certificate.Rows[i].Cells[3].Value.ToString();
                data_cert.str_year = txt_year_cer.Text;

                String strFileName = @str_folder + "\\Certificate_" + data_cert.str_cert_name + "_" + data_cert.str_reg_no + ".pdf";

                cls_Create_certificate cert_obj = new cls_Create_certificate();

                cert_obj.Certificate_generation(data_cert, strFileName);
            }

            MessageBox.Show("All Certificated are generated");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    string[] files = Directory.GetFiles(fbd.SelectedPath);

                    txt_file_to_save_marks_card.Text = fbd.SelectedPath;
                }
            }
        }

        private void btn_select_cert_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    string[] files = Directory.GetFiles(fbd.SelectedPath);

                    txt_certi_sele_path.Text = fbd.SelectedPath;
                }
            }
        }





    }
}
