﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace marks_card
{


    public class single_ton
    {

        private static single_ton instance;

        public cls_student_marks[] stuf_obj;

        private single_ton() { }

        public static single_ton GetInstance()
        {
            if (instance == null)
            {
                instance = new single_ton();
            }
            return instance;
        }



    }
}
