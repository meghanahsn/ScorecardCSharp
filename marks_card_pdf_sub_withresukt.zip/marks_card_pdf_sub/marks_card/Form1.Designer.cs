﻿namespace marks_card
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_file_to_save_marks_card = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox_center_code = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_student_name = new System.Windows.Forms.TextBox();
            this.txt_reg_no = new System.Windows.Forms.TextBox();
            this.txt_examination_center = new System.Windows.Forms.TextBox();
            this.txt_file_path = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox_exam_held = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_father_name = new System.Windows.Forms.TextBox();
            this.dateTimePicker_date_of_issue = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox_sem = new System.Windows.Forms.ComboBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_tt_obt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_internal_max = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_internal_obt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_exam_obt = new System.Windows.Forms.TextBox();
            this.txt_external_tt_max = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.btn_proceed = new System.Windows.Forms.Button();
            this.txt_total_marks_words = new System.Windows.Forms.TextBox();
            this.txt_result = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView_marks = new System.Windows.Forms.DataGridView();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.btn_generate = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txt_certi_sele_path = new System.Windows.Forms.TextBox();
            this.btn_select_cert = new System.Windows.Forms.Button();
            this.txt_year_cer = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btn_generate_certificate = new System.Windows.Forms.Button();
            this.dataGridView_Certificate = new System.Windows.Forms.DataGridView();
            this.txt_certi_file = new System.Windows.Forms.TextBox();
            this.btn_read_cetificate = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_marks)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Certificate)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(798, 741);
            this.tabControl1.TabIndex = 41;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(790, 715);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Marks Card";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txt_file_to_save_marks_card);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.comboBox_center_code);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.txt_student_name);
            this.panel1.Controls.Add(this.txt_reg_no);
            this.panel1.Controls.Add(this.txt_examination_center);
            this.panel1.Controls.Add(this.txt_file_path);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.comboBox_exam_held);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txt_father_name);
            this.panel1.Controls.Add(this.dateTimePicker_date_of_issue);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.comboBox_sem);
            this.panel1.Controls.Add(this.btn_close);
            this.panel1.Controls.Add(this.btn_clear);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.txt_tt_obt);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txt_internal_max);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txt_internal_obt);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txt_exam_obt);
            this.panel1.Controls.Add(this.txt_external_tt_max);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.btn_proceed);
            this.panel1.Controls.Add(this.txt_total_marks_words);
            this.panel1.Controls.Add(this.txt_result);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.dataGridView_marks);
            this.panel1.Controls.Add(this.btn_calculate);
            this.panel1.Controls.Add(this.btn_generate);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(12, 16);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(774, 692);
            this.panel1.TabIndex = 40;
            // 
            // txt_file_to_save_marks_card
            // 
            this.txt_file_to_save_marks_card.Location = new System.Drawing.Point(183, 605);
            this.txt_file_to_save_marks_card.Margin = new System.Windows.Forms.Padding(2);
            this.txt_file_to_save_marks_card.Name = "txt_file_to_save_marks_card";
            this.txt_file_to_save_marks_card.Size = new System.Drawing.Size(583, 20);
            this.txt_file_to_save_marks_card.TabIndex = 43;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(16, 602);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 24);
            this.button2.TabIndex = 42;
            this.button2.Text = "Select Folder";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox_center_code
            // 
            this.comboBox_center_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_center_code.FormattingEnabled = true;
            this.comboBox_center_code.Items.AddRange(new object[] {
            "01-BANGALORE",
            "02-BANGALORE",
            "03-MYSORE ",
            "05-HASSAN",
            "06-MANGALORE",
            "07-GULBARGA",
            "08-BELGAUM",
            "09-DANDELI",
            "10-HOSPET",
            "11-HUBLI",
            "12-HARIHAR",
            "14-MADDUR",
            "15-KUDALASANGAMA",
            "16-KANAKAPURA",
            "18-LINGASUGUR",
            "19-GUDALUPET",
            "20-KADUR",
            "21-HUMANABAD",
            "22-KOLAR",
            "23-TUMKUR",
            "24-SHIVAMOGA",
            "26-GOWRIBIDANURU"});
            this.comboBox_center_code.Location = new System.Drawing.Point(569, 153);
            this.comboBox_center_code.Name = "comboBox_center_code";
            this.comboBox_center_code.Size = new System.Drawing.Size(197, 24);
            this.comboBox_center_code.TabIndex = 41;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(423, 153);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(143, 20);
            this.label18.TabIndex = 40;
            this.label18.Text = "Exam Center Code";
            // 
            // txt_student_name
            // 
            this.txt_student_name.Location = new System.Drawing.Point(177, 74);
            this.txt_student_name.Margin = new System.Windows.Forms.Padding(2);
            this.txt_student_name.Name = "txt_student_name";
            this.txt_student_name.Size = new System.Drawing.Size(199, 20);
            this.txt_student_name.TabIndex = 11;
            // 
            // txt_reg_no
            // 
            this.txt_reg_no.Location = new System.Drawing.Point(177, 101);
            this.txt_reg_no.Margin = new System.Windows.Forms.Padding(2);
            this.txt_reg_no.Name = "txt_reg_no";
            this.txt_reg_no.Size = new System.Drawing.Size(199, 20);
            this.txt_reg_no.TabIndex = 13;
            // 
            // txt_examination_center
            // 
            this.txt_examination_center.Location = new System.Drawing.Point(177, 128);
            this.txt_examination_center.Margin = new System.Windows.Forms.Padding(2);
            this.txt_examination_center.Multiline = true;
            this.txt_examination_center.Name = "txt_examination_center";
            this.txt_examination_center.Size = new System.Drawing.Size(199, 45);
            this.txt_examination_center.TabIndex = 15;
            // 
            // txt_file_path
            // 
            this.txt_file_path.Location = new System.Drawing.Point(177, 45);
            this.txt_file_path.Margin = new System.Windows.Forms.Padding(2);
            this.txt_file_path.Name = "txt_file_path";
            this.txt_file_path.Size = new System.Drawing.Size(199, 20);
            this.txt_file_path.TabIndex = 38;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(84, 338);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(451, 17);
            this.label17.TabIndex = 39;
            this.label17.Text = "CLICK ON READ RECORD TO DISPLAY THE MARKS OF A STUDENT";
            // 
            // comboBox_exam_held
            // 
            this.comboBox_exam_held.FormattingEnabled = true;
            this.comboBox_exam_held.Items.AddRange(new object[] {
            "APRIL-MAY 2017",
            "NOV-DEC 2017",
            "APRIL- MAY 2018",
            "NOV - DEC 2018",
            "APRIL-MAY 2019",
            "NOV - DEC 2019",
            "APRIL-MAY 2020",
            "NOV - DEC 2020",
            "APRIL-MAY 2021",
            "NOV - DEC 2021",
            "APRIL-MAY 2022",
            "NOV - DEC 2022"});
            this.comboBox_exam_held.Location = new System.Drawing.Point(569, 73);
            this.comboBox_exam_held.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_exam_held.Name = "comboBox_exam_held";
            this.comboBox_exam_held.Size = new System.Drawing.Size(197, 21);
            this.comboBox_exam_held.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(194, -3);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(362, 24);
            this.label11.TabIndex = 30;
            this.label11.Text = "Govt Tool Room And Training  Center";
            // 
            // txt_father_name
            // 
            this.txt_father_name.Location = new System.Drawing.Point(569, 42);
            this.txt_father_name.Margin = new System.Windows.Forms.Padding(2);
            this.txt_father_name.Name = "txt_father_name";
            this.txt_father_name.Size = new System.Drawing.Size(197, 20);
            this.txt_father_name.TabIndex = 12;
            // 
            // dateTimePicker_date_of_issue
            // 
            this.dateTimePicker_date_of_issue.Location = new System.Drawing.Point(569, 104);
            this.dateTimePicker_date_of_issue.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker_date_of_issue.Name = "dateTimePicker_date_of_issue";
            this.dateTimePicker_date_of_issue.Size = new System.Drawing.Size(197, 20);
            this.dateTimePicker_date_of_issue.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(280, 18);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 17);
            this.label12.TabIndex = 31;
            this.label12.Text = "Marks Card Entry\r\n";
            // 
            // comboBox_sem
            // 
            this.comboBox_sem.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.comboBox_sem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_sem.FormattingEnabled = true;
            this.comboBox_sem.Items.AddRange(new object[] {
            "<--Select-->",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboBox_sem.Location = new System.Drawing.Point(569, 130);
            this.comboBox_sem.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_sem.Name = "comboBox_sem";
            this.comboBox_sem.Size = new System.Drawing.Size(199, 21);
            this.comboBox_sem.TabIndex = 19;
            // 
            // btn_close
            // 
            this.btn_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.Location = new System.Drawing.Point(546, 639);
            this.btn_close.Margin = new System.Windows.Forms.Padding(2);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(133, 25);
            this.btn_close.TabIndex = 38;
            this.btn_close.Text = "Close/Exit";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(345, 639);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(2);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(95, 25);
            this.btn_clear.TabIndex = 37;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(16, 39);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 26);
            this.button1.TabIndex = 32;
            this.button1.Text = "Import Data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(392, 527);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 17);
            this.label14.TabIndex = 35;
            this.label14.Text = "Max Exam marks";
            // 
            // txt_tt_obt
            // 
            this.txt_tt_obt.Location = new System.Drawing.Point(183, 551);
            this.txt_tt_obt.Margin = new System.Windows.Forms.Padding(2);
            this.txt_tt_obt.Name = "txt_tt_obt";
            this.txt_tt_obt.Size = new System.Drawing.Size(199, 20);
            this.txt_tt_obt.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(423, 128);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Select Semester";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(392, 501);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(185, 17);
            this.label16.TabIndex = 37;
            this.label16.Text = "Examination obtained Marks";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(423, 101);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "Date of issue";
            // 
            // txt_internal_max
            // 
            this.txt_internal_max.Location = new System.Drawing.Point(183, 526);
            this.txt_internal_max.Margin = new System.Windows.Forms.Padding(2);
            this.txt_internal_max.Name = "txt_internal_max";
            this.txt_internal_max.Size = new System.Drawing.Size(199, 20);
            this.txt_internal_max.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(423, 74);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Exam Held During ";
            // 
            // txt_internal_obt
            // 
            this.txt_internal_obt.Location = new System.Drawing.Point(183, 500);
            this.txt_internal_obt.Margin = new System.Windows.Forms.Padding(2);
            this.txt_internal_obt.Name = "txt_internal_obt";
            this.txt_internal_obt.Size = new System.Drawing.Size(199, 20);
            this.txt_internal_obt.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(423, 43);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Father Name";
            // 
            // txt_exam_obt
            // 
            this.txt_exam_obt.Location = new System.Drawing.Point(579, 500);
            this.txt_exam_obt.Margin = new System.Windows.Forms.Padding(2);
            this.txt_exam_obt.Name = "txt_exam_obt";
            this.txt_exam_obt.Size = new System.Drawing.Size(186, 20);
            this.txt_exam_obt.TabIndex = 27;
            // 
            // txt_external_tt_max
            // 
            this.txt_external_tt_max.Location = new System.Drawing.Point(565, 526);
            this.txt_external_tt_max.Margin = new System.Windows.Forms.Padding(2);
            this.txt_external_tt_max.Name = "txt_external_tt_max";
            this.txt_external_tt_max.Size = new System.Drawing.Size(200, 20);
            this.txt_external_tt_max.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 529);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 17);
            this.label13.TabIndex = 34;
            this.label13.Text = "Total Session Marks";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 189);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(759, 139);
            this.dataGridView1.TabIndex = 33;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 501);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(170, 17);
            this.label15.TabIndex = 36;
            this.label15.Text = "Sessional obtained Marks";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_proceed
            // 
            this.btn_proceed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_proceed.Location = new System.Drawing.Point(595, 332);
            this.btn_proceed.Margin = new System.Windows.Forms.Padding(2);
            this.btn_proceed.Name = "btn_proceed";
            this.btn_proceed.Size = new System.Drawing.Size(136, 28);
            this.btn_proceed.TabIndex = 1;
            this.btn_proceed.Text = "Read Record";
            this.btn_proceed.UseVisualStyleBackColor = true;
            this.btn_proceed.Click += new System.EventHandler(this.btn_proceed_Click);
            // 
            // txt_total_marks_words
            // 
            this.txt_total_marks_words.Location = new System.Drawing.Point(183, 581);
            this.txt_total_marks_words.Margin = new System.Windows.Forms.Padding(2);
            this.txt_total_marks_words.Name = "txt_total_marks_words";
            this.txt_total_marks_words.Size = new System.Drawing.Size(583, 20);
            this.txt_total_marks_words.TabIndex = 17;
            // 
            // txt_result
            // 
            this.txt_result.Location = new System.Drawing.Point(564, 551);
            this.txt_result.Margin = new System.Windows.Forms.Padding(2);
            this.txt_result.Name = "txt_result";
            this.txt_result.Size = new System.Drawing.Size(201, 20);
            this.txt_result.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 552);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 17);
            this.label10.TabIndex = 29;
            this.label10.Text = "Total obtained marks";
            // 
            // dataGridView_marks
            // 
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_marks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridView_marks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_marks.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridView_marks.Location = new System.Drawing.Point(7, 364);
            this.dataGridView_marks.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_marks.Name = "dataGridView_marks";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_marks.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridView_marks.RowTemplate.Height = 28;
            this.dataGridView_marks.Size = new System.Drawing.Size(759, 103);
            this.dataGridView_marks.TabIndex = 0;
            // 
            // btn_calculate
            // 
            this.btn_calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate.Location = new System.Drawing.Point(16, 471);
            this.btn_calculate.Margin = new System.Windows.Forms.Padding(2);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(149, 28);
            this.btn_calculate.TabIndex = 23;
            this.btn_calculate.Text = "Calculate Marks";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // btn_generate
            // 
            this.btn_generate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_generate.Location = new System.Drawing.Point(45, 639);
            this.btn_generate.Margin = new System.Windows.Forms.Padding(2);
            this.btn_generate.Name = "btn_generate";
            this.btn_generate.Size = new System.Drawing.Size(166, 25);
            this.btn_generate.TabIndex = 21;
            this.btn_generate.Text = "Generate Marks Card";
            this.btn_generate.UseVisualStyleBackColor = true;
            this.btn_generate.Click += new System.EventHandler(this.btn_generate_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 579);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Total marks words";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(392, 554);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 8;
            this.label7.Text = "Result";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Student Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 101);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Register Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 131);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Exam Center";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txt_certi_sele_path);
            this.tabPage2.Controls.Add(this.btn_select_cert);
            this.tabPage2.Controls.Add(this.txt_year_cer);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.btn_generate_certificate);
            this.tabPage2.Controls.Add(this.dataGridView_Certificate);
            this.tabPage2.Controls.Add(this.txt_certi_file);
            this.tabPage2.Controls.Add(this.btn_read_cetificate);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(774, 721);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Certificate";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txt_certi_sele_path
            // 
            this.txt_certi_sele_path.Location = new System.Drawing.Point(163, 314);
            this.txt_certi_sele_path.Margin = new System.Windows.Forms.Padding(2);
            this.txt_certi_sele_path.Name = "txt_certi_sele_path";
            this.txt_certi_sele_path.Size = new System.Drawing.Size(227, 20);
            this.txt_certi_sele_path.TabIndex = 7;
            // 
            // btn_select_cert
            // 
            this.btn_select_cert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_select_cert.Location = new System.Drawing.Point(15, 309);
            this.btn_select_cert.Margin = new System.Windows.Forms.Padding(2);
            this.btn_select_cert.Name = "btn_select_cert";
            this.btn_select_cert.Size = new System.Drawing.Size(118, 23);
            this.btn_select_cert.TabIndex = 6;
            this.btn_select_cert.Text = "Select Folder";
            this.btn_select_cert.UseVisualStyleBackColor = true;
            this.btn_select_cert.Click += new System.EventHandler(this.btn_select_cert_Click);
            // 
            // txt_year_cer
            // 
            this.txt_year_cer.Location = new System.Drawing.Point(162, 58);
            this.txt_year_cer.Name = "txt_year_cer";
            this.txt_year_cer.Size = new System.Drawing.Size(228, 20);
            this.txt_year_cer.TabIndex = 5;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 60);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(112, 18);
            this.label19.TabIndex = 4;
            this.label19.Text = "Year of Passing";
            // 
            // btn_generate_certificate
            // 
            this.btn_generate_certificate.Location = new System.Drawing.Point(15, 348);
            this.btn_generate_certificate.Margin = new System.Windows.Forms.Padding(2);
            this.btn_generate_certificate.Name = "btn_generate_certificate";
            this.btn_generate_certificate.Size = new System.Drawing.Size(131, 30);
            this.btn_generate_certificate.TabIndex = 3;
            this.btn_generate_certificate.Text = "Generate Certificates";
            this.btn_generate_certificate.UseVisualStyleBackColor = true;
            this.btn_generate_certificate.Click += new System.EventHandler(this.btn_generate_certificate_Click);
            // 
            // dataGridView_Certificate
            // 
            this.dataGridView_Certificate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Certificate.Location = new System.Drawing.Point(15, 90);
            this.dataGridView_Certificate.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_Certificate.Name = "dataGridView_Certificate";
            this.dataGridView_Certificate.RowTemplate.Height = 28;
            this.dataGridView_Certificate.Size = new System.Drawing.Size(491, 198);
            this.dataGridView_Certificate.TabIndex = 2;
            // 
            // txt_certi_file
            // 
            this.txt_certi_file.Location = new System.Drawing.Point(163, 27);
            this.txt_certi_file.Margin = new System.Windows.Forms.Padding(2);
            this.txt_certi_file.Name = "txt_certi_file";
            this.txt_certi_file.Size = new System.Drawing.Size(227, 20);
            this.txt_certi_file.TabIndex = 1;
            // 
            // btn_read_cetificate
            // 
            this.btn_read_cetificate.Location = new System.Drawing.Point(15, 24);
            this.btn_read_cetificate.Margin = new System.Windows.Forms.Padding(2);
            this.btn_read_cetificate.Name = "btn_read_cetificate";
            this.btn_read_cetificate.Size = new System.Drawing.Size(125, 24);
            this.btn_read_cetificate.TabIndex = 0;
            this.btn_read_cetificate.Text = "Import Certificate Data";
            this.btn_read_cetificate.UseVisualStyleBackColor = true;
            this.btn_read_cetificate.Click += new System.EventHandler(this.btn_read_cetificate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(798, 741);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "GT & TC";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_marks)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Certificate)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txt_certi_file;
        private System.Windows.Forms.Button btn_read_cetificate;
        private System.Windows.Forms.DataGridView dataGridView_Certificate;
        private System.Windows.Forms.Button btn_generate_certificate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_student_name;
        private System.Windows.Forms.TextBox txt_reg_no;
        private System.Windows.Forms.TextBox txt_examination_center;
        private System.Windows.Forms.TextBox txt_file_path;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox_exam_held;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_father_name;
        private System.Windows.Forms.DateTimePicker dateTimePicker_date_of_issue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox_sem;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_tt_obt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_internal_max;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_internal_obt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_exam_obt;
        private System.Windows.Forms.TextBox txt_external_tt_max;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btn_proceed;
        private System.Windows.Forms.TextBox txt_total_marks_words;
        private System.Windows.Forms.TextBox txt_result;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView_marks;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.Button btn_generate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_year_cer;
        private System.Windows.Forms.ComboBox comboBox_center_code;
        private System.Windows.Forms.TextBox txt_file_to_save_marks_card;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_certi_sele_path;
        private System.Windows.Forms.Button btn_select_cert;
    }
}

