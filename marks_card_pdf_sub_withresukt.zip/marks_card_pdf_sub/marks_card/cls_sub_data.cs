﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace marks_card
{
   public class cls_sub_data
    {
       public static String [] sem_2_data = { "Production Technology -II", "Engineering Mathematics-II", "Basic Elecreical & Electronics","Engineering Drawing","Basic Computer Application Lab","Workshop-II" };
       public static String[] sem_1_data = { "Production Technology -II", "Engineering Mathematics-II", "Basic Elecreical & Electronics", "Engineering Drawing", "Basic Computer Application Lab", "Workshop-II" };

       public static int count_next_record = 0;

       public static List<String> coloumn = new List<String>();
       
       

       public static Dictionary<String, String> max_val = new Dictionary<String, String>();
       public static Dictionary<String, String> min_val = new Dictionary<String, String>();

       public static List<String> min_ses_val = new List<String>();
       public static List<String> Max_ses_val = new List<String>();
       public static List<String> min_exam_val = new List<String>();
       public static List<String> max_exam_val = new List<String>();

    }
}
