﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace marks_card
{
   public class Subjec_marks
    {
       String name;
       int max_session;
       int max_exam;
       int obt_session;
       int obt_exam;
       int total;
    }
}
