﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace marks_card
{
    public class cls_student_marks
    {
        String str_Student_name;
        String str_usn;
        Subjec_marks[] str_subjects; // = new Subjec_marks[10];
    }
}



