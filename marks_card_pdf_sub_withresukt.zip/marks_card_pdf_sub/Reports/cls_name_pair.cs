﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Reports
{
   public class cls_name_pair
    {
       public String str_name;
       public String str_value;
    }
}
