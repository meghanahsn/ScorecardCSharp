﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


namespace Reports
{
   public class cls_Create_certificate
    {
        private Font m_FontHeading;
        private Font m_FontHeading_top;
        private Font m_FontSubHeading;
        private Font m_FontValue;
        private Font m_FontColoum;
        private Font m_FontColoum_head;

        public cls_Create_certificate()     
        {
            m_FontHeading = FontFactory.GetFont(FontFactory.TIMES_BOLD, 13, Font.BOLD, BaseColor.BLACK);
            m_FontSubHeading = FontFactory.GetFont(FontFactory.TIMES_BOLD, 10, Font.BOLD, BaseColor.BLACK);
            m_FontValue = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.BLACK);
            m_FontColoum = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);

            m_FontColoum_head = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);
            m_FontHeading_top= FontFactory.GetFont(FontFactory.TIMES_ROMAN, 16, Font.BOLD, BaseColor.BLACK);
        }

        public void Certificate_generation(cls_marks_data data, String strFileName)
        {
            try
            {
                Document objDoc = new Document(iTextSharp.text.PageSize.A4_LANDSCAPE, 10, 10, 40, 10);
                PdfWriter objPdfWriter = PdfWriter.GetInstance(objDoc, new FileStream(strFileName, FileMode.Create));

                objDoc.Open();
                //Creating Table For Headder
                PdfPTable Headder = new PdfPTable(1);
                Headder.SpacingAfter = 40f;

                Headder.SpacingBefore = 50f;



                Phrase cert_name = new Phrase();
                cert_name.Add(new Chunk("      "+data.str_cert_name, m_FontHeading));
                PdfPCell cert_nameCell = new PdfPCell(cert_name);
                cert_nameCell.Border = 0;
                cert_nameCell.HorizontalAlignment = 1;
                cert_nameCell.PaddingTop = 318f;
                cert_nameCell.PaddingLeft = 40f;
                                         
                Headder.AddCell(cert_nameCell);

                Phrase empty = new Phrase();
                empty.Add(new Chunk("", m_FontHeading));
                PdfPCell emptyCell = new PdfPCell(empty);
                emptyCell.Border = 0;

                Headder.AddCell(emptyCell);

                PdfPTable middle = new PdfPTable(3);
                Headder.SpacingAfter = 40f;

                Headder.SpacingBefore = 50f;

                /*Phrase course = new Phrase();
                course.Add(new Chunk("", m_FontHeading));
                PdfPCell courseCell = new PdfPCell(course);
                courseCell.Border = 0;
                courseCell.HorizontalAlignment = 0;
                middle.AddCell(courseCell);*/

                Phrase result = new Phrase();
                result.Add(new Chunk("         " + data.str_result, m_FontSubHeading));
                PdfPCell resultCell = new PdfPCell(result);
                resultCell.Border = 0;
                resultCell.PaddingTop = 52f;
                middle.AddCell(resultCell);

                Phrase year = new Phrase();
                year.Add(new Chunk("         " + data.str_year, m_FontSubHeading));
                PdfPCell yearCell = new PdfPCell(year);
                yearCell.Border = 0;
                yearCell.PaddingTop = 52f;
                yearCell.PaddingLeft = 20;
                middle.AddCell(yearCell);
               

                Phrase center = new Phrase();
                center.Add(new Chunk("   "+data.str_center, m_FontSubHeading));
                PdfPCell centerCell = new PdfPCell(center);
                centerCell.Border = 0;
                centerCell.HorizontalAlignment = 0;
                centerCell.PaddingTop = 52f;
                middle.AddCell(centerCell);

                middle.AddCell(emptyCell);

                objDoc.Add(Headder);
                objDoc.Add(middle);

                
               // objDoc.NewPage();

                //PdfPTable second_p = new PdfPTable(2);
                //second_p.SpacingAfter = 40f;

                //second_p.SpacingBefore = 35f;



                //Phrase regno = new Phrase();
                //regno.Add(new Chunk(data.str_reg_no, m_FontHeading));
                //PdfPCell regnoCell = new PdfPCell(regno);
                //regnoCell.Border = 0;
                //regnoCell.HorizontalAlignment = 2;
                //second_p.AddCell(regnoCell);


                //second_p.AddCell(emptyCell);


               // objDoc.Add(second_p);

                objDoc.Close();
            }
            catch (Exception Ex)
            {

            }
        }

       

    }
}
