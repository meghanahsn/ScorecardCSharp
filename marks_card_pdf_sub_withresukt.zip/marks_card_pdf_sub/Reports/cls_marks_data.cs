﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Reports
{
    public class cls_marks_data
    {
        public cls_name_pair m_exam_center;
        public cls_name_pair m_center_code;
        public cls_name_pair m_student_name;
        public cls_name_pair m_reg_no;
        public cls_name_pair m_father_name;
        public cls_name_pair m_date_of_issue;
        public cls_name_pair m_exam_held;
        public cls_name_pair m_total_marks_in_word;
        public cls_name_pair m_result;
        public cls_name_pair m_entered_by;
        public cls_name_pair m_entered_date;
        public cls_name_pair m_Verified_by;
        public cls_name_pair m_Verified_date;
        public cls_name_pair m_Semester;

        public String str_cert_name;
        public String str_reg_no;
        public String str_center;
        public String str_year_from;
        public String str_year_too;
        public String str_course;
        public String str_result;
        public String str_year;



        public cls_name_pair m_sessional_max;
        public cls_name_pair m_sessional_obt;
        public cls_name_pair m_external_max;
        public cls_name_pair m_external_obt;
        public cls_name_pair m_both_tt;

        public List<String> m_sessional_max_lst;
        public List<String> m_sessional_obt_lst;
        public List<String> m_external_max_lst;
        public List<String> m_external_obt_lst;
        public List<String> m_Remark_obt_lst;
        public List<String> m_subject__namelst;

        public cls_marks_data()
        {
            m_sessional_max_lst = new List<String>();
            m_sessional_obt_lst = new List<String>();
            m_external_max_lst = new List<String>();
            m_external_obt_lst = new List<String>();
            m_Remark_obt_lst = new List<string>();
            m_subject__namelst = new List<String>();
            m_Semester = new cls_name_pair();

            m_exam_center = new cls_name_pair();
            m_exam_center.str_name = "Center Code: STU";
            m_center_code = new cls_name_pair();
            m_center_code.str_name = " Center Code: STD ";
            m_date_of_issue = new cls_name_pair();
            m_date_of_issue.str_name = "Date of issue :";
            m_entered_by = new cls_name_pair();
            m_entered_by.str_name = " Entered By : ";
            m_entered_date = new cls_name_pair();
            m_entered_date.str_name = "Enetered by : ";
            m_exam_held = new cls_name_pair();
            m_exam_held.str_name = "Examination Held During : ";

            m_external_max = new cls_name_pair();
            m_external_max.str_name = "";

            m_both_tt = new cls_name_pair();

            m_external_obt = new cls_name_pair();
            m_father_name = new cls_name_pair();
            m_father_name.str_name = "Father Name :";
            m_reg_no = new cls_name_pair();
            m_reg_no.str_name = "Register No :";
            m_result = new cls_name_pair();
            m_Semester = new cls_name_pair();

            m_sessional_max = new cls_name_pair();
            m_sessional_obt = new cls_name_pair();
            m_student_name = new cls_name_pair();
            m_student_name.str_name = "Student's Name :";

            m_total_marks_in_word = new cls_name_pair();
            m_total_marks_in_word.str_name = "total Marks in Word  : ";
            m_Verified_by = new cls_name_pair();
            m_Verified_date = new cls_name_pair();


        }



    }
}
