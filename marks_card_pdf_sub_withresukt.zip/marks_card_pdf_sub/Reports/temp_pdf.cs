﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


namespace Reports
{
    class temp_pdf
    {
         private Font m_FontHeading;
        private Font m_FontHeading_top;
        private Font m_FontSubHeading;
        private Font m_FontValue;
        private Font m_FontColoum;
        private Font m_FontColoum_head;

        public  temp_pdf()
        {
            m_FontHeading = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 13, Font.BOLD, BaseColor.BLACK);
            m_FontSubHeading = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 11, Font.BOLD, BaseColor.BLACK);
            m_FontValue = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.BLACK);
            m_FontColoum = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);

            m_FontColoum_head = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);
            m_FontHeading_top= FontFactory.GetFont(FontFactory.TIMES_ROMAN, 16, Font.BOLD, BaseColor.BLACK);
        }

        public void marks_card_generation(cls_marks_data data, String strFileName)
        {
            try
            {
                Document objDoc = new Document(iTextSharp.text.PageSize.A4_LANDSCAPE, 0, 0, 0, 0);
                PdfWriter objPdfWriter = PdfWriter.GetInstance(objDoc, new FileStream(strFileName, FileMode.Create));

                objDoc.Open();
                //Creating Table For Headder
                PdfPTable Headder = new PdfPTable(1);
                Headder.SpacingAfter = 40f;

                Headder.SpacingBefore = 5f;

                
                



                Phrase GovtName = new Phrase();
               // GovtName.Add(new Chunk("Govt. Tool Room & Training  Center", m_FontHeading_top));
                GovtName.Add(new Chunk("                        ", m_FontHeading_top));
                PdfPCell GovtNameCell = new PdfPCell(GovtName);
                GovtNameCell.Border = 0;
                GovtNameCell.HorizontalAlignment = 1;
                Headder.AddCell(GovtNameCell);

                Phrase Kar = new Phrase();
                Kar.Add(new Chunk("Karnataka", m_FontColoum));
                PdfPCell KarCell = new PdfPCell(Kar);
                KarCell.Border = 0;
                KarCell.HorizontalAlignment = 1;
                Headder.AddCell(KarCell);

                Phrase phHeadder = new Phrase();
                phHeadder.Add(new Chunk("DIPLOMA IN TOOL & DIE MAKING", m_FontHeading));
                PdfPCell phHeadderCell = new PdfPCell(phHeadder);
                phHeadderCell.Border = 0;
                phHeadderCell.HorizontalAlignment = 1;
                Headder.AddCell(phHeadderCell);


                Phrase phHead_stat = new Phrase();
                phHead_stat.Add(new Chunk("STATEMENT OF MARKS", m_FontHeading));
                PdfPCell phHead_statCell = new PdfPCell(phHead_stat);
                phHead_statCell.Border = 0;
                phHead_statCell.HorizontalAlignment = 1;
                Headder.AddCell(phHead_statCell);


                Phrase phHead_sem = new Phrase();
                phHead_sem.Add(new Chunk(data.m_Semester.str_value + "SEMESTER EXAMINATION", m_FontHeading));
                PdfPCell phHead_semCell = new PdfPCell(phHead_sem);
                phHead_semCell.Border = 0;
                phHead_semCell.HorizontalAlignment = 1;
                Headder.AddCell(phHead_semCell);


                //Creating Table For Headder
                PdfPTable basic_info = new PdfPTable(2);
                basic_info.SpacingAfter = 5f;

                Phrase center_code = new Phrase();
                center_code.Add(new Chunk(data.m_center_code.str_name + "    " + data.m_center_code.str_value, m_FontSubHeading));
                PdfPCell center_codeCell = new PdfPCell(center_code);
                center_codeCell.Border = 0;
                 
                basic_info.AddCell(center_codeCell);

                Phrase empty = new Phrase();
                empty.Add(new Chunk("", m_FontHeading));
                PdfPCell emptyCell = new PdfPCell(empty);
                emptyCell.Border = 0;
                
                basic_info.AddCell(emptyCell);

                Phrase stu_name = new Phrase();
                stu_name.Add(new Chunk(data.m_student_name.str_name + "    " + data.m_student_name.str_value, m_FontSubHeading));
                PdfPCell stu_nameCell = new PdfPCell(stu_name);
                stu_nameCell.Border = 0;
                 
                basic_info.AddCell(stu_nameCell);

                Phrase std_reg = new Phrase();
                std_reg.Add(new Chunk(data.m_reg_no.str_name + "  " + data.m_reg_no.str_value, m_FontSubHeading));
                PdfPCell std_regCell = new PdfPCell(std_reg);
                std_regCell.Border = 0;
                 
                basic_info.AddCell(std_regCell);


                Phrase father_name = new Phrase();
                father_name.Add(new Chunk(data.m_father_name.str_name + "  " + data.m_father_name.str_value, m_FontSubHeading));
                PdfPCell father_nameCell = new PdfPCell(father_name);
                father_nameCell.Border = 0;
                 
                basic_info.AddCell(father_nameCell);

                basic_info.AddCell(emptyCell);

                Phrase emax_held = new Phrase();
                emax_held.Add(new Chunk(data.m_exam_held.str_name + "    " + data.m_exam_held.str_value, m_FontSubHeading));
                PdfPCell emax_heldCell = new PdfPCell(emax_held);
                emax_heldCell.Border = 0;
                
                basic_info.AddCell(emax_heldCell);

                Phrase date_of_issue = new Phrase();
                date_of_issue.Add(new Chunk(data.m_date_of_issue.str_name + "  " + data.m_date_of_issue.str_value, m_FontSubHeading));
                PdfPCell date_of_issueCell = new PdfPCell(date_of_issue);
                date_of_issueCell.Border = 0;
                

                basic_info.AddCell(date_of_issueCell);



                float[] width = { 0.10f, 0.320f, 0.10f, 0.10f, 0.10f, 0.10f, 0.10f, 0.10f };
                PdfPTable marks_main = new PdfPTable(width);
                marks_main.SpacingAfter = 25f;
                marks_main.SpacingBefore = 5f;

                Phrase slNo = new Phrase();
                slNo.Add(new Chunk("SlNo", m_FontColoum_head));
                PdfPCell slNoCell = new PdfPCell(slNo);
                slNoCell.HorizontalAlignment = 1;
                slNoCell.Rowspan = 2;
                marks_main.AddCell(slNoCell);

                Phrase Subs = new Phrase();
                Subs.Add(new Chunk("Subjects ", m_FontColoum_head));
                PdfPCell SubsCell = new PdfPCell(Subs);
                SubsCell.HorizontalAlignment = 1;
                SubsCell.Rowspan = 2;
                marks_main.AddCell(SubsCell);

                Phrase Max_marks = new Phrase();
                Max_marks.Add(new Chunk("Maximum Marks", m_FontColoum_head));
                PdfPCell Max_marksCell = new PdfPCell(Max_marks);
                Max_marksCell.HorizontalAlignment = 1;
                Max_marksCell.Colspan = 2;
                marks_main.AddCell(Max_marksCell);

                Phrase obt_marks = new Phrase();
                obt_marks.Add(new Chunk("Obtained Marks", m_FontColoum_head));
                PdfPCell obt_marksCell = new PdfPCell(obt_marks);
                obt_marksCell.HorizontalAlignment = 1;
                obt_marksCell.Colspan = 3;
                marks_main.AddCell(obt_marksCell);

                Phrase Re_marks = new Phrase();
                Re_marks.Add(new Chunk("Remarks", m_FontColoum_head));
                PdfPCell Re_marksCell = new PdfPCell(Re_marks);
                Re_marksCell.HorizontalAlignment = 1;
                Re_marksCell.Rowspan = 2;
                marks_main.AddCell(Re_marksCell);

                Phrase sess_max = new Phrase();
                sess_max.Add(new Chunk("Sessional", m_FontColoum_head));
                PdfPCell sess_maxCell = new PdfPCell(sess_max);
                sess_maxCell.HorizontalAlignment = 1;
                marks_main.AddCell(sess_maxCell);

                Phrase External_max = new Phrase();
                External_max.Add(new Chunk("Examination", m_FontColoum_head));
                PdfPCell External_maxCell = new PdfPCell(External_max);
                External_maxCell.HorizontalAlignment = 1;
                marks_main.AddCell(External_maxCell);

                Phrase ob_sess = new Phrase();
                ob_sess.Add(new Chunk("Sessional", m_FontColoum_head));
                PdfPCell ob_sessCell = new PdfPCell(ob_sess);
                ob_sessCell.HorizontalAlignment = 1;
                marks_main.AddCell(ob_sessCell);

                Phrase ob_exam = new Phrase();
                ob_exam.Add(new Chunk("Examination", m_FontColoum_head));
                PdfPCell ob_examCell = new PdfPCell(ob_exam);
                ob_examCell.HorizontalAlignment = 1;
                marks_main.AddCell(ob_examCell);

                Phrase total = new Phrase();
                total.Add(new Chunk("total", m_FontColoum_head));
                PdfPCell totalCell = new PdfPCell(total);
                totalCell.HorizontalAlignment = 1;
                marks_main.AddCell(totalCell);

                for (int i = 0; i < data.m_subject__namelst.Count; i++)
                {
                    Phrase slNo_val = new Phrase();
                    slNo_val.Add(new Chunk((i + 1).ToString(), m_FontValue));
                    PdfPCell slNo_valCell = new PdfPCell(slNo_val);
                    slNo_valCell.HorizontalAlignment = 1;
                   
                    marks_main.AddCell(slNo_valCell);

                    Phrase Subs_val = new Phrase();
                    Subs_val.Add(new Chunk(data.m_subject__namelst[i].ToString(), m_FontValue));
                    PdfPCell Subs_valCell = new PdfPCell(Subs_val);
                    Subs_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(Subs_valCell);

                    Phrase sess_max_val = new Phrase();
                    sess_max_val.Add(new Chunk(data.m_sessional_max_lst[i].ToString(), m_FontValue));
                    PdfPCell sess_max_valCell = new PdfPCell(sess_max_val);
                    sess_max_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(sess_max_valCell);

                    Phrase External_max_val = new Phrase();
                    External_max_val.Add(new Chunk(data.m_external_max_lst[i].ToString(), m_FontValue));
                    PdfPCell External_max_valCell = new PdfPCell(External_max_val);
                    External_max_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(External_max_valCell);

                    Phrase ob_sess_val = new Phrase();
                    ob_sess_val.Add(new Chunk(data.m_sessional_obt_lst[i].ToString(), m_FontSubHeading));
                    PdfPCell ob_sess_valCell = new PdfPCell(ob_sess_val);
                    ob_sess_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(ob_sess_valCell);

                    Phrase ob_exam_val = new Phrase();
                    ob_exam_val.Add(new Chunk(data.m_external_obt_lst[i].ToString(), m_FontSubHeading));
                    PdfPCell ob_exam_valCell = new PdfPCell(ob_exam_val);
                    ob_exam_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(ob_exam_valCell);
                     

                    Phrase total_val = new Phrase();
                    total_val.Add(new Chunk((int.Parse(data.m_external_obt_lst[i].ToString()) + int.Parse(data.m_sessional_obt_lst[i].ToString())).ToString(), m_FontSubHeading));
                    PdfPCell total_valCell = new PdfPCell(total_val);
                    total_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(total_valCell);

                    Phrase Re_marks_val = new Phrase();
                    Re_marks_val.Add(new Chunk(data.m_Remark_obt_lst[i].ToString(), m_FontSubHeading));
                    PdfPCell Re_marks_valCell = new PdfPCell(Re_marks_val);
                    Re_marks_valCell.HorizontalAlignment = 1;
                    marks_main.AddCell(Re_marks_valCell);

                }

                Phrase slNo_val_btm = new Phrase();
                slNo_val_btm.Add(new Chunk("", m_FontHeading));
                PdfPCell slNo_val_btmCell = new PdfPCell(slNo_val_btm);
                slNo_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(slNo_val_btmCell);

                Phrase Subs_val_btm = new Phrase();
                Subs_val_btm.Add(new Chunk("Grand total", m_FontSubHeading));
                PdfPCell Subs_val_btmCell = new PdfPCell(Subs_val_btm);
                Subs_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(Subs_val_btmCell);

                Phrase sess_max_val_btm = new Phrase();
                sess_max_val_btm.Add(new Chunk(data.m_sessional_max.str_value, m_FontSubHeading));
                PdfPCell sess_max_val_btmCell = new PdfPCell(sess_max_val_btm);
                sess_max_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(sess_max_val_btmCell);

                Phrase External_max_val_btm = new Phrase();
                External_max_val_btm.Add(new Chunk(data.m_external_max.str_value, m_FontSubHeading));
                PdfPCell External_max_val_btmCell = new PdfPCell(External_max_val_btm);
                External_max_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(External_max_val_btmCell);

                Phrase ob_sess_val_btm = new Phrase();
                ob_sess_val_btm.Add(new Chunk(data.m_sessional_obt.str_value, m_FontSubHeading));
                PdfPCell ob_sess_val_btmCell = new PdfPCell(ob_sess_val_btm);
                ob_sess_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(ob_sess_val_btmCell);

                Phrase ob_exam_val_btm = new Phrase();
                ob_exam_val_btm.Add(new Chunk(data.m_external_obt.str_value, m_FontSubHeading));
                PdfPCell ob_exam_val_btmCell = new PdfPCell(ob_exam_val_btm);
                ob_exam_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(ob_exam_val_btmCell);


                Phrase total_val_btm = new Phrase();
                total_val_btm.Add(new Chunk(data.m_both_tt.str_value, m_FontSubHeading));
                PdfPCell total_val_btmCell = new PdfPCell(total_val_btm);
                total_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(total_val_btmCell);

                Phrase Re_marks_val_btm = new Phrase();
                Re_marks_val_btm.Add(new Chunk(" ", m_FontColoum));
                PdfPCell Re_marks_val_btmCell = new PdfPCell(Re_marks_val_btm);
                Re_marks_val_btmCell.HorizontalAlignment = 1;
                marks_main.AddCell(Re_marks_val_btmCell);



                PdfPTable buttom_tt = new PdfPTable(2);
                buttom_tt.SpacingAfter = 5f;

                Phrase tt_words = new Phrase();
                tt_words.Add(new Chunk(data.m_total_marks_in_word.str_name + "  " + data.m_total_marks_in_word.str_value,  m_FontColoum));
                PdfPCell tt_wordsCell = new PdfPCell(tt_words);
                tt_wordsCell.Colspan = 2;
                tt_wordsCell.Border = 0;
                buttom_tt.AddCell(tt_wordsCell);

                Phrase Result = new Phrase();
                Result.Add(new Chunk("Result : " + data.m_result.str_value, m_FontColoum));
                PdfPCell ResulCell = new PdfPCell(Result);
                ResulCell.Colspan = 2;
                ResulCell.Border = 0;
                buttom_tt.AddCell(ResulCell);
        
                Phrase Note = new Phrase();
                Note.Add(new Chunk("Note : "  , m_FontColoum));
                PdfPCell NoteCell = new PdfPCell(Note);
                NoteCell.Colspan = 2;
                
                NoteCell.Border = 0;
                buttom_tt.AddCell(NoteCell);



                Phrase Entered_by = new Phrase();
                Entered_by.Add(new Chunk("Entered By :     " + data.m_entered_by.str_value + "              Date : " + data.m_entered_date.str_value , m_FontColoum));
                PdfPCell Entered_byCell = new PdfPCell(Entered_by);
                
                Entered_byCell.Border = 0;
                buttom_tt.AddCell(Entered_byCell);


                Phrase Veri_by = new Phrase();
                Veri_by.Add(new Chunk("Verified By : " + data.m_Verified_by.str_value + "                  Date : " + data.m_Verified_date.str_value, m_FontColoum));
                PdfPCell Veri_byCell = new PdfPCell(Veri_by);
                 
                Veri_byCell.Border = 0;
                buttom_tt.AddCell(Veri_byCell);

                buttom_tt.AddCell(emptyCell); // Empty Cell for Row Space
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell);


                Phrase sing_stu = new Phrase(); 
                sing_stu.Add(new Chunk("Signature of the Candidate: ", m_FontHeading));
                PdfPCell sing_stuCell = new PdfPCell(sing_stu);
                 
                sing_stuCell.Border = 0;
                buttom_tt.AddCell(sing_stuCell);


                Phrase sing_chife = new Phrase();
                sing_chife.Add(new Chunk("CHIFE EXAMINAR: ", m_FontHeading));
                PdfPCell sing_chifeCell = new PdfPCell(sing_chife);
                sing_chifeCell.HorizontalAlignment = 1;
                sing_chifeCell.Border = 0;
                buttom_tt.AddCell(sing_chifeCell);

                buttom_tt.AddCell(emptyCell); // Empty Cell for Row Space
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell); // Empty Cell for Row Space
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell);
                buttom_tt.AddCell(emptyCell);

                Phrase prin_stu = new Phrase();
                prin_stu.Add(new Chunk("PRINCIPAL: ", m_FontHeading));
                PdfPCell prin_stuCell = new PdfPCell(prin_stu);

                prin_stuCell.Border = 0;
                buttom_tt.AddCell(prin_stuCell);


                Phrase GM_chife = new Phrase();
                GM_chife.Add(new Chunk("GENERAL MANAGER - TRG.: ", m_FontHeading));
                PdfPCell GM_chifeCell = new PdfPCell(GM_chife);
                GM_chifeCell.HorizontalAlignment = 1;
                GM_chifeCell.Border = 0;
                buttom_tt.AddCell(GM_chifeCell);


                objDoc.Add(Headder);

                objDoc.Add(basic_info);
                objDoc.Add(marks_main);
                objDoc.Add(buttom_tt);

                objDoc.Close();
            }
            catch (Exception Ex)
            {

            }
        }
    }
}
